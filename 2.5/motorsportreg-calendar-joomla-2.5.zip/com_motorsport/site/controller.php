<?php

/**
 * @version		$Id: controller.php 
 * @package		Joomla 2.5
 * @subpackage	Components
 * @copyright	Copyright (C) 2011 - 2013 Open Source Matters, Inc. All rights reserved.
 * @author		Yogesh Arora
 * 
 * @license		License sun softwares  version 2 or later
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// import Joomla controller library
jimport('joomla.application.component.controller');



/**
 * Hello World Component Controller
 */
class MotorSportController extends JController
{
}
