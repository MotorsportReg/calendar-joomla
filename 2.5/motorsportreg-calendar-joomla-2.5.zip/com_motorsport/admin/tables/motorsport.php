<?php

/**
 * @version		$Id: MotorSport.php 46 2010-11-21 17:27:33Z chdemko $
 * @package		Joomla 2.5
 * @subpackage	Components
 * @copyright	Copyright (C) 2011 - 2013 Open Source Matters, Inc. All rights reserved.
 * @author		Yogesh Arora
 * @link		http://joomlacode.org/gf/project/MotorSport_1_6/
 * @license		License sun softwares  version 2 or later
 */

// No direct access
defined('_JEXEC') or die('Restricted access');

// import Joomla table library
jimport('joomla.database.table');

/**
 * Hello Table class
 */
class MotorSportTableMotorSport extends JTable
{
	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function __construct(&$db) 
	{
		parent::__construct('#__motorsport', 'id', $db);
	}
}
