<?php

/**
 * @version		$Id: MotorSport.php 46 2010-11-21 17:27:33Z chdemko $
 * @package		Joomla 2.5
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// import Joomla controllerform library
jimport('joomla.application.component.controllerform');

/**
 * MotorSport Controller
 */
class MotorSportControllerMotorSport extends JControllerForm
{
}
