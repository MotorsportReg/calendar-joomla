<?php
/**
 * default template file for MotorSports view of MotorSport component
 *
 * @version		$Id: default.php 46 2010-11-21 17:27:33Z chdemko $
 * @package		Joomla 2.5
 * @subpackage	Components
 * @copyright	Copyright (C) 2011 - 2013 Open Source Matters, Inc. All rights reserved.
 * @author		Yogesh Arora
 * @link		http://joomlacode.org/gf/project/MotorSport_1_6/
 * @license		License sun softwares  version 2 or later
 */
// No direct access to this file
defined('_JEXEC') or die('Restricted Access');
// load tooltip behavior
JHtml::_('behavior.tooltip');
?>
<form action="<?php echo JRoute::_('index.php?option=com_MotorSport'); ?>" method="post" name="adminForm">
	<table class="adminlist">
		<thead><?php echo $this->loadTemplate('head');?></thead>
		<tfoot><?php echo $this->loadTemplate('foot');?></tfoot>
		<tbody><?php echo $this->loadTemplate('body');?></tbody>
	</table>
	<div>
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="boxchecked" value="0" />
		<?php echo JHtml::_('form.token'); ?>
	</div>
</form>
