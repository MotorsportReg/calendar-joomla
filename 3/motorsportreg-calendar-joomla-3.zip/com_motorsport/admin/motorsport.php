<?php

/**
 * @version		$Id: hello.php 
 * @package		Joomla 2.5
 * @subpackage	Components
 * @copyright	Copyright (C) 2011 - 2013 Open Source Matters, Inc. All rights reserved.
 * @author		Yogesh Arora
 * @link		http://joomlacode.org/gf/project/MotorSport_1_6/
 * @license		License sun softwares  version 2 or later
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// import joomla controller library
jimport('joomla.application.component.controller');

// Get an instance of the controller prefixed by MotorSport
$controller = JControllerLegacy::getInstance('MotorSport');

// Perform the Request task
$controller->execute(JRequest::getCmd('task'));

// Redirect if set by the controller
$controller->redirect();
