<?php
/**
 * @version		$Id: edit.php 
 * @package		Joomla 2.5
 * @subpackage	Components
 * @copyright	Copyright (C) 2011 - 2013 Open Source Matters, Inc. All rights reserved.
 * @author		Yogesh Arora
 * @link		http://joomlacode.org/gf/project/MotorSport_1_6/
 * @license		License sun softwares  version 2 or later
 */
// No direct access
defined('_JEXEC') or die('Restricted access');
JHtml::_('behavior.tooltip');
?>
<form action="<?php echo JRoute::_('index.php?option=com_MotorSport&layout=edit&id='.(int) $this->item->id); ?>" method="post" name="adminForm" id="MotorSport-form">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_MotorSport_MotorSport_DETAILS' ); ?></legend>
		<ul class="adminformlist">
<?php foreach($this->form->getFieldset() as $field): ?>
			<li><?php echo $field->label;echo $field->input;?></li>
<?php endforeach; ?>
		</ul>
	</fieldset>
	<div>
		<input type="hidden" name="task" value="MotorSport.edit" />
		<?php echo JHtml::_('form.token'); ?>
	</div>
</form>

