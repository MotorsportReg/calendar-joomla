<?php
/**
 * default head template file for MotorSports view of MotorSport component
 *
 * @version		$Id: default_foot.php 46 2010-11-21 17:27:33Z chdemko $
 * @package		Joomla 2.5
 */
// No direct access to this file
defined('_JEXEC') or die('Restricted Access');
?>

