<?php
/**
 * default head template file for MotorSports view of MotorSport component
 *
 * @version		$Id: default_head.php 51 2010-11-22 01:33:21Z chdemko $
 * @package		Joomla 2.5
 */
// No direct access to this file
defined('_JEXEC') or die('Restricted Access');
?>
<tr>
				
	<th style="text-align:left;" align="left">
		<?php //echo JText::_('Thanks for Using motorsport registration component ou can set the setting with below link '); ?>
	</th>
</tr>

